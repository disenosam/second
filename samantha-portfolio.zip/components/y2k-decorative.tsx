export default function Y2KDecorative() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-10 pointer-events-none overflow-hidden">
      <div className="container-custom relative">
        {/* Left Corner Decoration */}
        <div className="absolute left-4 bottom-4 w-24 h-24">
          <div className="absolute inset-0 border-l-4 border-b-4 border-verde rounded-bl-3xl"></div>
          <div className="absolute left-4 bottom-4 w-8 h-8 bg-verde rounded-full opacity-50"></div>
        </div>

        {/* Right Corner Decoration */}
        <div className="absolute right-4 bottom-4 w-24 h-24">
          <div className="absolute inset-0 border-r-4 border-b-4 border-rosa rounded-br-3xl"></div>
          <div className="absolute right-4 bottom-4 w-8 h-8 bg-rosa rounded-full opacity-50"></div>
        </div>

        {/* Center Decoration */}
        <div className="absolute left-1/2 -translate-x-1/2 bottom-0">
          <div className="relative w-64 h-16 overflow-hidden">
            <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-azul/30 to-transparent"></div>
            <div className="absolute inset-x-0 bottom-0 h-0.5 bg-azul"></div>
            <div className="absolute left-1/2 -translate-x-1/2 bottom-2 w-32 h-1 bg-azul/50"></div>
            <div className="absolute left-1/2 -translate-x-1/2 bottom-4 w-16 h-1 bg-azul/30"></div>
          </div>
        </div>
      </div>
    </div>
  )
}

