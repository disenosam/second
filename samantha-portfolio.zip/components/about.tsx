"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"

export default function About() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  return (
    <section id="about" className="section-padding bg-white relative">
      {/* Y2K Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-verde to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-rosa to-transparent"></div>

        <div className="absolute top-20 left-10 w-40 h-40">
          <div className="w-full h-full border-2 border-dashed border-verde/30 rounded-full animate-spin-slow"></div>
        </div>

        <div className="absolute bottom-20 right-10 w-32 h-32">
          <div className="w-full h-full border-2 border-dashed border-rosa/30 rounded-full animate-spin-slow-reverse"></div>
        </div>
      </div>

      <div className="container-custom">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h2
            className="text-3xl md:text-4xl mb-8 text-center relative inline-block"
            style={{ fontFamily: "var(--font-prosto-one)" }}
          >
            <span className="gradient-text">About Me</span>
            <div className="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-verde via-rosa to-azul"></div>
          </h2>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="aspect-square rounded-2xl overflow-hidden bg-gradient-to-br from-verde/20 via-rosa/20 to-azul/20 border border-white/30 shadow-xl">
                <img
                  src="/placeholder.svg?height=600&width=600"
                  alt="Samantha Quintero"
                  className="w-full h-full object-cover mix-blend-overlay"
                />
              </div>

              {/* Y2K Photo Decorations */}
              <div className="absolute -top-4 -left-4 w-8 h-8 border-l-2 border-t-2 border-verde"></div>
              <div className="absolute -top-4 -right-4 w-8 h-8 border-r-2 border-t-2 border-rosa"></div>
              <div className="absolute -bottom-4 -left-4 w-8 h-8 border-l-2 border-b-2 border-azul"></div>
              <div className="absolute -bottom-4 -right-4 w-8 h-8 border-r-2 border-b-2 border-verde"></div>

              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-verde rounded-full opacity-20 blur-2xl"></div>
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-rosa rounded-full opacity-20 blur-2xl"></div>
            </div>

            <div className="space-y-4">
              <p
                className="text-sm md:text-base leading-relaxed px-4 py-2 bg-gradient-to-r from-verde/5 to-rosa/5 border-l-2 border-verde rounded-r-lg"
                style={{ fontFamily: "var(--font-major-mono)" }}
              >
                Hello! I'm Samantha, a multidisciplinary designer with a passion for creating immersive digital
                experiences.
              </p>

              <p
                className="text-sm md:text-base leading-relaxed px-4 py-2 bg-gradient-to-r from-rosa/5 to-azul/5 border-l-2 border-rosa rounded-r-lg"
                style={{ fontFamily: "var(--font-major-mono)" }}
              >
                My work spans across 3D clothing design, branding, video editing, social media content, web prototyping,
                and illustration.
              </p>

              <p
                className="text-sm md:text-base leading-relaxed px-4 py-2 bg-gradient-to-r from-azul/5 to-verde/5 border-l-2 border-azul rounded-r-lg"
                style={{ fontFamily: "var(--font-major-mono)" }}
              >
                With expertise in tools like CLO 3D, Blender, Cinema 4D, Adobe Creative Suite, Procreate, DaVinci
                Resolve, Figma, and Canva, I bring creative visions to life through a blend of technical skill and
                artistic innovation.
              </p>

              <div className="pt-4">
                <a
                  href="#contact"
                  className="inline-block px-6 py-2 bg-gradient-to-r from-verde to-rosa text-white rounded-full hover:opacity-90 transition-opacity shadow-lg"
                  style={{ fontFamily: "var(--font-major-mono)" }}
                >
                  Get in Touch
                </a>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

