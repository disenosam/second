"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Mail, Phone, MapPin, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"

export default function Contact() {
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500))

    toast({
      title: "Message sent!",
      description: "Thank you for your message. I'll get back to you soon.",
    })

    setIsSubmitting(false)
    e.currentTarget.reset()
  }

  return (
    <section id="contact" className="section-padding bg-gray-50">
      <div className="container-custom">
        <h2 className="text-3xl md:text-4xl font-prosto mb-12 text-center">
          <span className="gradient-text">Get in Touch</span>
        </h2>

        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="grid md:grid-cols-2 gap-12"
        >
          <div className="bg-white p-8 rounded-xl shadow-sm">
            <h3 className="text-xl font-prosto mb-6">Send Me a Message</h3>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm mb-1">
                  Name
                </label>
                <Input id="name" name="name" placeholder="Your name" required />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm mb-1">
                  Email
                </label>
                <Input id="email" name="email" type="email" placeholder="Your email" required />
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm mb-1">
                  Subject
                </label>
                <Input id="subject" name="subject" placeholder="Subject" required />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm mb-1">
                  Message
                </label>
                <Textarea id="message" name="message" placeholder="Your message" rows={5} required />
              </div>

              <Button type="submit" className="w-full bg-verde hover:bg-verde/90 text-white" disabled={isSubmitting}>
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></span>
                    Sending...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    Send Message
                    <Send size={16} />
                  </span>
                )}
              </Button>
            </form>
          </div>

          <div className="flex flex-col justify-between">
            <div>
              <h3 className="text-xl font-prosto mb-6">Contact Information</h3>

              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-rosa/20 p-3 rounded-full">
                    <Mail className="w-5 h-5 text-rosa" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-1">Email</h4>
                    <p className="text-sm">hello@samanthaquintero.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-verde/20 p-3 rounded-full">
                    <Phone className="w-5 h-5 text-verde" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-1">Phone</h4>
                    <p className="text-sm">+1 (555) 123-4567</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-azul/20 p-3 rounded-full">
                    <MapPin className="w-5 h-5 text-azul" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold mb-1">Location</h4>
                    <p className="text-sm">Los Angeles, California</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 p-6 bg-gradient-to-br from-verde/20 via-rosa/20 to-azul/20 rounded-xl">
              <h4 className="text-lg font-prosto mb-3">Let's Work Together</h4>
              <p className="text-sm mb-4">
                Looking for a creative collaboration? I'm always open to new projects and opportunities.
              </p>
              <a
                href="mailto:hello@samanthaquintero.com"
                className="inline-block px-4 py-2 bg-white rounded-full text-sm hover:bg-gray-100 transition-colors"
              >
                Get Started
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

