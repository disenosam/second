"use client"

import { useRef, useState, useEffect } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, PerspectiveCamera, Environment, Float, MeshDistortMaterial } from "@react-three/drei"
import * as THREE from "three"

function Bubble({ position, color, speed, size }) {
  const ref = useRef()

  useFrame((state) => {
    ref.current.position.y = position[1] + Math.sin(state.clock.elapsedTime * speed) * 0.3
    ref.current.rotation.x = state.clock.elapsedTime * 0.2
    ref.current.rotation.z = state.clock.elapsedTime * 0.1
  })

  return (
    <mesh ref={ref} position={position}>
      <sphereGeometry args={[size, 32, 32]} />
      <MeshDistortMaterial
        color={color}
        speed={0.4}
        distort={0.3}
        envMapIntensity={1}
        clearcoat={1}
        clearcoatRoughness={0}
        metalness={0.1}
        roughness={0.1}
      />
    </mesh>
  )
}

function CyberCube({ position, color, speed, size }) {
  const ref = useRef()

  useFrame((state) => {
    ref.current.rotation.x = state.clock.elapsedTime * 0.2
    ref.current.rotation.y = state.clock.elapsedTime * 0.3
  })

  return (
    <mesh ref={ref} position={position}>
      <boxGeometry args={[size, size, size]} />
      <meshPhongMaterial color={color} shininess={100} specular={new THREE.Color(0xffffff)} />
    </mesh>
  )
}

function GlowingTorus({ position, color, speed, size }) {
  const ref = useRef()

  useFrame((state) => {
    ref.current.rotation.x = Math.PI / 2
    ref.current.rotation.z = state.clock.elapsedTime * 0.3
  })

  return (
    <mesh ref={ref} position={position}>
      <torusGeometry args={[size, size / 4, 16, 32]} />
      <meshPhongMaterial color={color} emissive={color} emissiveIntensity={0.4} shininess={100} />
    </mesh>
  )
}

function Grid() {
  const gridSize = 10
  const gridDivisions = 10

  return (
    <gridHelper
      args={[gridSize, gridDivisions, "#ffb6c0", "#61fefd"]}
      position={[0, -2, 0]}
      rotation={[Math.PI / 2, 0, 0]}
    />
  )
}

export default function Y2KScene() {
  const [isMounted, setIsMounted] = useState(false)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  if (!isMounted) return null

  return (
    <div className="absolute inset-0 z-0">
      <Canvas>
        <PerspectiveCamera makeDefault position={[0, 0, 10]} fov={50} />
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <pointLight position={[-10, -10, -10]} intensity={0.5} />

        <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
          <Bubble position={[-3, 0, 0]} color="#ffb6c0" speed={1.5} size={1.2} />
        </Float>

        <Float speed={1.5} rotationIntensity={0.3} floatIntensity={0.8}>
          <CyberCube position={[3, 1, -2]} color="#b9c405" speed={1} size={1} />
        </Float>

        <Float speed={1} rotationIntensity={0.2} floatIntensity={0.5}>
          <GlowingTorus position={[0, -1, -1]} color="#61fefd" speed={0.8} size={1.5} />
        </Float>

        <Grid />

        <Environment preset="studio" />
        <OrbitControls enableZoom={false} enablePan={false} enableRotate={false} />
      </Canvas>
    </div>
  )
}

