"use client"

import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import { Shirt, Palette, Video, Instagram, Globe, PenTool } from "lucide-react"

const services = [
  {
    icon: <Shirt className="w-10 h-10" />,
    title: "3D Clothing Design",
    description: "Creating realistic 3D garments and fashion items using CLO 3D and Blender.",
    color: "bg-verde",
  },
  {
    icon: <Palette className="w-10 h-10" />,
    title: "Branding",
    description: "Developing cohesive brand identities including logos, color palettes, and style guides.",
    color: "bg-rosa",
  },
  {
    icon: <Video className="w-10 h-10" />,
    title: "Video Editing",
    description: "Crafting engaging video content with DaVinci Resolve and Adobe Premiere Pro.",
    color: "bg-azul",
  },
  {
    icon: <Instagram className="w-10 h-10" />,
    title: "Social Media Content",
    description: "Creating eye-catching visuals and graphics optimized for social platforms.",
    color: "bg-verde",
  },
  {
    icon: <Globe className="w-10 h-10" />,
    title: "Web Prototyping",
    description: "Designing intuitive user interfaces and interactive prototypes with Figma.",
    color: "bg-rosa",
  },
  {
    icon: <PenTool className="w-10 h-10" />,
    title: "Illustration",
    description: "Hand-crafted digital illustrations using Procreate and Adobe Illustrator.",
    color: "bg-azul",
  },
]

export default function Services() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 },
    },
  }

  return (
    <section id="services" className="section-padding bg-gray-50 relative">
      {/* Y2K Background Grid */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-10">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `linear-gradient(to right, ${services[0].color} 1px, transparent 1px), 
                            linear-gradient(to bottom, ${services[1].color} 1px, transparent 1px)`,
            backgroundSize: "40px 40px",
          }}
        ></div>
      </div>

      <div className="container-custom">
        <h2
          className="text-3xl md:text-4xl mb-12 text-center relative inline-block"
          style={{ fontFamily: "var(--font-prosto-one)" }}
        >
          <span className="gradient-text">My Services</span>
          <div className="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-verde via-rosa to-azul"></div>
        </h2>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {services.map((service, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="bg-white rounded-xl p-6 shadow-lg border border-white/50 backdrop-blur-sm hover:shadow-xl transition-all"
              style={{
                background: `linear-gradient(135deg, white 0%, white 80%, ${service.color}20 100%)`,
              }}
            >
              <div
                className={`${service.color} w-16 h-16 rounded-lg flex items-center justify-center text-white mb-4 shadow-md relative overflow-hidden`}
              >
                {/* Y2K Icon Background */}
                <div
                  className="absolute inset-0 opacity-30"
                  style={{
                    backgroundImage: `radial-gradient(circle at 30% 30%, white 0%, transparent 20%)`,
                  }}
                ></div>
                {service.icon}
              </div>
              <h3 className="text-xl mb-3" style={{ fontFamily: "var(--font-prosto-one)" }}>
                {service.title}
              </h3>
              <p className="text-sm text-gray-600" style={{ fontFamily: "var(--font-major-mono)" }}>
                {service.description}
              </p>

              {/* Y2K Corner Decoration */}
              <div
                className="absolute bottom-2 right-2 w-6 h-6 border-r-2 border-b-2 rounded-br-lg opacity-30"
                style={{ borderColor: service.color.replace("bg-", "") }}
              ></div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

