import Link from "next/link"
import { Instagram, Twitter, Linkedin, Github } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container-custom">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <Link href="/" className="text-2xl font-prosto text-verde">
              SQ
            </Link>
            <p className="mt-2 text-sm text-gray-400 max-w-xs">
              Creating digital experiences that blend artistry with innovation.
            </p>
          </div>

          <div className="flex flex-col items-center md:items-end">
            <div className="flex space-x-4 mb-4">
              <a href="#" className="p-2 rounded-full bg-gray-800 hover:bg-verde/20 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 rounded-full bg-gray-800 hover:bg-rosa/20 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 rounded-full bg-gray-800 hover:bg-azul/20 transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 rounded-full bg-gray-800 hover:bg-verde/20 transition-colors">
                <Github className="w-5 h-5" />
              </a>
            </div>

            <p className="text-xs text-gray-500">
              © {new Date().getFullYear()} Samantha Quintero. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  )
}

