"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { ArrowDown } from "lucide-react"
import Y2KScene from "./y2k-3d-scene"

export default function Hero() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Y2K 3D Scene */}
      <Y2KScene />

      {/* Background Elements */}
      <div
        className="absolute inset-0 bg-gradient-to-br from-azul/10 via-rosa/10 to-verde/10 opacity-50"
        style={{ transform: `translateY(${scrollY * 0.1}px)` }}
      />

      <div
        className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-verde/20 blur-3xl"
        style={{ transform: `translate(${scrollY * 0.05}px, ${scrollY * -0.05}px)` }}
      />

      <div
        className="absolute bottom-1/4 right-1/4 w-40 h-40 rounded-full bg-rosa/20 blur-3xl"
        style={{ transform: `translate(${scrollY * -0.07}px, ${scrollY * 0.03}px)` }}
      />

      <div
        className="absolute top-1/2 right-1/3 w-24 h-24 rounded-full bg-azul/20 blur-3xl"
        style={{ transform: `translate(${scrollY * 0.06}px, ${scrollY * 0.08}px)` }}
      />

      {/* Content */}
      <div className="container-custom text-center z-10">
        <motion.div
          className="relative inline-block mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1
            className="text-4xl md:text-6xl lg:text-7xl gradient-text"
            style={{ fontFamily: "var(--font-prosto-one)" }}
          >
            Samantha Quintero
          </h1>

          {/* Y2K Decorative Elements */}
          <div className="absolute -top-4 -left-4 w-8 h-8 border-l-4 border-t-4 border-verde"></div>
          <div className="absolute -top-4 -right-4 w-8 h-8 border-r-4 border-t-4 border-rosa"></div>
          <div className="absolute -bottom-4 -left-4 w-8 h-8 border-l-4 border-b-4 border-azul"></div>
          <div className="absolute -bottom-4 -right-4 w-8 h-8 border-r-4 border-b-4 border-verde"></div>
        </motion.div>

        <motion.div
          className="relative inline-block mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <p
            className="text-lg md:text-xl lg:text-2xl tracking-wider px-6 py-2 bg-white/10 backdrop-blur-sm rounded-lg border border-white/20"
            style={{ fontFamily: "var(--font-major-mono)" }}
          >
            Creative Designer & Digital Artist
          </p>

          {/* Y2K Pill Decoration */}
          <div className="absolute -left-2 top-1/2 -translate-y-1/2 w-1 h-8 bg-verde rounded-full"></div>
          <div className="absolute -right-2 top-1/2 -translate-y-1/2 w-1 h-8 bg-rosa rounded-full"></div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <a
            href="#about"
            className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-verde via-rosa to-azul text-white rounded-full hover:opacity-90 transition-opacity shadow-lg"
            style={{ fontFamily: "var(--font-major-mono)" }}
          >
            Explore My Work
            <ArrowDown size={16} />
          </a>
        </motion.div>
      </div>
    </section>
  )
}

