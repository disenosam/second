"use client"

import { useEffect, useState } from "react"

export default function Y2KHeader() {
  const [time, setTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="fixed top-0 left-0 right-0 z-40 pointer-events-none">
      <div className="container-custom py-2">
        <div className="flex justify-between items-center">
          <div className="bg-azul/80 backdrop-blur-sm px-4 py-1 rounded-b-lg shadow-lg border border-white/30">
            <p className="text-xs" style={{ fontFamily: "var(--font-major-mono)" }}>
              {time.toLocaleTimeString()}
            </p>
          </div>

          <div className="bg-rosa/80 backdrop-blur-sm px-4 py-1 rounded-b-lg shadow-lg border border-white/30">
            <p className="text-xs" style={{ fontFamily: "var(--font-major-mono)" }}>
              Y2K MODE ACTIVATED
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

