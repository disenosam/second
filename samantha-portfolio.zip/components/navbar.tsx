"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <nav className="fixed w-full bg-white/80 backdrop-blur-md z-50 py-4 border-b border-gray-100">
      <div className="container-custom flex justify-between items-center">
        <Link href="/" className="text-xl text-verde" style={{ fontFamily: "var(--font-prosto-one)" }}>
          SQ
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <Link
            href="#about"
            className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
            style={{ fontFamily: "var(--font-major-mono)" }}
          >
            About
          </Link>
          <Link
            href="#services"
            className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
            style={{ fontFamily: "var(--font-major-mono)" }}
          >
            Services
          </Link>
          <Link
            href="#portfolio"
            className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
            style={{ fontFamily: "var(--font-major-mono)" }}
          >
            Portfolio
          </Link>
          <Link
            href="#contact"
            className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
            style={{ fontFamily: "var(--font-major-mono)" }}
          >
            Contact
          </Link>
          <ThemeToggle />
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center">
          <ThemeToggle />
          <button onClick={toggleMenu} className="ml-4 p-1">
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-16 left-0 right-0 bg-white/95 backdrop-blur-md border-b border-gray-100 py-4">
          <div className="container-custom flex flex-col space-y-4">
            <Link
              href="#about"
              className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
              onClick={toggleMenu}
              style={{ fontFamily: "var(--font-major-mono)" }}
            >
              About
            </Link>
            <Link
              href="#services"
              className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
              onClick={toggleMenu}
              style={{ fontFamily: "var(--font-major-mono)" }}
            >
              Services
            </Link>
            <Link
              href="#portfolio"
              className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
              onClick={toggleMenu}
              style={{ fontFamily: "var(--font-major-mono)" }}
            >
              Portfolio
            </Link>
            <Link
              href="#contact"
              className="text-sm uppercase tracking-wider hover:text-verde transition-colors"
              onClick={toggleMenu}
              style={{ fontFamily: "var(--font-major-mono)" }}
            >
              Contact
            </Link>
          </div>
        </div>
      )}
    </nav>
  )
}

