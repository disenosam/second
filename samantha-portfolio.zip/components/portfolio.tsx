"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useInView } from "react-intersection-observer"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

const categories = ["All", "3D Design", "Branding", "Video", "Web", "Illustration"]

const projects = [
  {
    title: "Futuristic Apparel",
    category: "3D Design",
    image: "/placeholder.svg?height=600&width=800",
    description: "3D clothing design for a futuristic fashion collection using CLO 3D and Blender.",
    tools: ["CLO 3D", "Blender", "Adobe Photoshop"],
  },
  {
    title: "Eco Brand Identity",
    category: "Branding",
    image: "/placeholder.svg?height=600&width=800",
    description: "Complete brand identity for an eco-friendly startup including logo, color palette, and guidelines.",
    tools: ["Adobe Illustrator", "Adobe InDesign", "Figma"],
  },
  {
    title: "Product Launch Video",
    category: "Video",
    image: "/placeholder.svg?height=600&width=800",
    description: "Promotional video for a new product launch with motion graphics and visual effects.",
    tools: ["DaVinci Resolve", "After Effects", "Cinema 4D"],
  },
  {
    title: "E-commerce Website",
    category: "Web",
    image: "/placeholder.svg?height=600&width=800",
    description: "UI/UX design and interactive prototype for an e-commerce platform.",
    tools: ["Figma", "Adobe XD", "Webflow"],
  },
  {
    title: "Digital Art Series",
    category: "Illustration",
    image: "/placeholder.svg?height=600&width=800",
    description: "Series of digital illustrations for a children's book project.",
    tools: ["Procreate", "Adobe Illustrator", "Adobe Photoshop"],
  },
  {
    title: "Virtual Fashion Show",
    category: "3D Design",
    image: "/placeholder.svg?height=600&width=800",
    description: "3D virtual fashion show with animated models and garments.",
    tools: ["CLO 3D", "Cinema 4D", "Blender"],
  },
]

export default function Portfolio() {
  const [activeCategory, setActiveCategory] = useState("All")
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  })

  const filteredProjects =
    activeCategory === "All" ? projects : projects.filter((project) => project.category === activeCategory)

  return (
    <section id="portfolio" className="section-padding">
      <div className="container-custom">
        <h2 className="text-3xl md:text-4xl font-prosto mb-12 text-center">
          <span className="gradient-text">My Work</span>
        </h2>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category, index) => (
            <button
              key={index}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm transition-colors ${
                activeCategory === category ? "bg-verde text-white" : "bg-gray-100 hover:bg-gray-200"
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <motion.div
          ref={ref}
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredProjects.map((project, index) => (
            <Dialog key={index}>
              <DialogTrigger asChild>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="group cursor-pointer"
                >
                  <div className="relative overflow-hidden rounded-xl aspect-[4/3]">
                    <img
                      src={project.image || "/placeholder.svg"}
                      alt={project.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                      <div className="p-4 text-white">
                        <h3 className="text-lg font-prosto">{project.title}</h3>
                        <p className="text-sm opacity-80">{project.category}</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle className="font-prosto text-xl">{project.title}</DialogTitle>
                  <DialogDescription className="text-sm text-gray-500">{project.category}</DialogDescription>
                </DialogHeader>
                <div className="mt-4">
                  <img
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    className="w-full h-48 object-cover rounded-lg mb-4"
                  />
                  <p className="text-sm mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tools.map((tool, i) => (
                      <span key={i} className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

