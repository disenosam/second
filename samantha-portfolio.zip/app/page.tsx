import Navbar from "@/components/navbar"
import Hero from "@/components/hero"
import About from "@/components/about"
import Services from "@/components/services"
import Portfolio from "@/components/portfolio"
import Contact from "@/components/contact"
import Footer from "@/components/footer"
import Y2KHeader from "@/components/y2k-header"
import Y2KDecorative from "@/components/y2k-decorative"
import Y2KCursor from "@/components/y2k-cursor"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Y2KHeader />
      <Navbar />
      <Hero />
      <About />
      <Services />
      <Portfolio />
      <Contact />
      <Footer />
      <Y2KDecorative />
      <Y2KCursor />
    </main>
  )
}

